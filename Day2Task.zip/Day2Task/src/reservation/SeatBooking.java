/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reservation;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */
public class SeatBooking {
    
    //int seatsAvailable[] = new int[10];
    int[] seatsAvailable = {1,1,1,1,0,1,1,1,1,0};
    int seatOption = 0;
    
    SeatBooking() {
        //for (int i=0; i<seatsAvailable.length; i++)
        //this.seatsAvailable[10] = new int[10] {1,1,1,1,0,1,1,1,1,0};
    }
    
    
    void booking(){
    int seatOption=0;
        Scanner myInput = new Scanner(System.in);
        System.out.println("Enter Seat Booking option (1 for Smoking & 2 for Non-Smoking)");
        seatOption = myInput.nextInt();
        if (seatOption == 1)
        {
            booking_Smoke();
        }
        else if (seatOption == 2)
        {
            booking_NonSmoke();
        }
        else
        {
            System.out.println("Enter Valid input");
        }
    }
    
    void booking_Smoke(){
        
            for (int i=0; i<5; i++)
            {
                if (seatsAvailable[i]==0)
                {
                    System.out.println("Ticket Booked Successfully in Smoking Area. Seat Number:" + (i+1));
                    seatsAvailable[i]=1;
                    break;
                }
                else if (seatsAvailable[4]==1)
                {
                    if (seatsAvailable[9]==1)
                    {
                        System.out.println("Next flight will be in next three hours.");
                        System.exit(0);
                    
                    }
                    else
                    {
                        Scanner input = new Scanner(System.in);  
                         int option;
                         System.out.println("Tickets in Smoking section is not available. Enter 1 to travel in Non-Smoking...");
                        option = input.nextInt();
                        if (option == 1)
                        {
                            booking_NonSmoke();
                        }
                        else
                        {
                        System.out.println("Next flight will be in next three hours.");
                        System.exit(0);
                        }
                    }
                    
                }
                
                else
                {
                    continue;
                }   
                
            }
        
    }
    void booking_NonSmoke(){
           for (int i=5; i<10; i++)
            {
                if (seatsAvailable[i]==0)
                {
                    System.out.println("Ticket Booked Successfully in Non-Smoking. Seat Number:" + (i+1));
                    seatsAvailable[i]=1;
                    System.exit(0);
                    break;
                    
                }
                else if (seatsAvailable[9]==1)
                {
                    if (seatsAvailable[4]==1)
                    {
                    System.out.println("Fligh Full! Next flight will be in next three hours.");
                    System.exit(0);
                    }
                    else
                    {
                    Scanner input = new Scanner(System.in);  
                    int option;
                    System.out.println("Tickets in Non-Smoking section is not available. Enter 1 to travel in Smoking...");
                    option = input.nextInt();
                    if (option == 1)
                    {
                         booking_Smoke();
                    }
                    else
                    {
                         System.out.println("Next flight will be in next three hours.");
                            System.exit(0);
                     }
                    }
                }
                else
                {
                    continue;
                }   
                
            }
        }
    }
    
    
    
}
