/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author macstudent
 */
public class JavaApplication3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Student student1 = new Student("A",1,"B");
        Student student2 = new Student("C",4,"D");
        Student student3 = new Student("B",2,"A");
        
        ArrayList<Student> library = new ArrayList<Student>() ;
        
        library.add(student1);
        library.add(student2);
        library.add(student3);
        
         Collections.sort(library, new studentNameComparator());
           for (Student ss: library){
            ss.displayInfo();
        }
           
           System.out.println("=AGE=");
           Collections.sort(library, new studentAgeComparator());
           for (Student ss: library){
            ss.displayInfo();
        }
    }
    
}
