/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import java.util.Comparator;

/**
 *
 * @author macstudent
 */
public class Student {
    String name;
    int age;
    String grade;
    
    Student(){
    this.name = "unknown";
    this.age = 0;
    this.grade = "";
}
    Student(String name, int age, String grade){
    this.name = "unknown";
    this.age = 0;
    this.grade = "";
    }
    
    void setName(String name){
        this.name = name;
    }
    
    String getName() {
        return this.name;
    }
    
    void setAge(int age){
        this.age = age;
    }
    
    int setAge() {
        return this.age;
    }
    
    void setGrade(String grade){
        this.grade = grade;
    }
    
    String getGrade() {
        return this.grade;
    }
    
    void displayInfo() {
        System.out.println("Student name : " + this.name + "\n Student age : " + this.age + "\n Student grade : " + this.grade);
    }
}

class studentNameComparator implements Comparator<Student> {

    @Override
    public int compare(Student o1, Student o2) {
        return o2.name.compareToIgnoreCase(o1.name);
    }

 
    
}

class studentAgeComparator implements Comparator<Student> {

    @Override
    public int compare(Student o1, Student o2) {
         if (o1.age == o2.age)
            return 0;
        else if (o1.age > o2.age)
            return 1;
        else
            return -1;
    }
    }

    
    
}
