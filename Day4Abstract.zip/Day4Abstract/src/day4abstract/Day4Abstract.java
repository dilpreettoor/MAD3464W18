/*
 * 
 * 
 * Academic work
 */
package day4abstract;

/**
 *
 * @author dst
 */
public class Day4Abstract {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //MyShape obj1= new MyShape(); ref(a)
        
        Circle c1 = new Circle();
        c1.draw();
        c1.display("Its a Circle !!");
    }
    
    
    
}
//In abstract class we need not create any object since we can directly call the method using only its class name. ref(a)
    abstract class MyShape{
        int x;
        int y;
        
        abstract void draw();
        
        void display(String msg){
            System.out.println(msg);
        }
    }
    
class Circle extends MyShape
{

   @Override
   void draw() 
   {
       System.out.println("Drawing circle");
       super.x = 20;
       super.y = 30;
       
       System.out.println("X: "+super.x);
       System.out.println("Y: "+super.y);
   }
}
        
    
    
   abstract class Rectangle extends MyShape {
        int h;
        abstract void draw();
        
    }